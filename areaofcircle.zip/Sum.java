/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Sum
{
    int a,b;
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    System.out.println("Enter values:");
	   int a = sc.nextInt();
	  int b = sc.nextInt();
		System.out.println("Sum:"+ (a/b));
	}
}