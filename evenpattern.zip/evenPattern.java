/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class evenPattern
{
	public static void main(String[] args) {
	     int n=0;
	    for(int i=1;i<=4;i++){
	    for(int j=1;j<=i;j++){
	       n=n+2;
		System.out.print(n+" ");
	}
	System.out.println();
} 
}
}