import java.util.Scanner;

class Restaurant {

    String orderedItems = "";
    int totalBill = 0;

    void showMenu() {
        System.out.println("\n------ MENU ------");
        System.out.println("Pizza    - ₹100");
        System.out.println("Burger   - ₹80");
        System.out.println("Shawarma - ₹120");
    }

    void addOrder(String food, int quantity) {

        int price = 0;

        if (food.equalsIgnoreCase("Pizza")) {
            price = 100;
        } else if (food.equalsIgnoreCase("Burger")) {
            price = 80;
        } else if (food.equalsIgnoreCase("Shawarma")) {
            price = 120;
        }

        int itemTotal = price * quantity;

        orderedItems += food + " x " + quantity + " = ₹" + itemTotal + "\n";

        totalBill += itemTotal;
    }

    void getBill() {
        System.out.println("\n------ BILL ------");
        System.out.println(orderedItems);
        System.out.println("Total Bill = ₹" + totalBill);
    }
}

public class FoodItem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Restaurant r = new Restaurant();

        String choice;

        do {

            r.showMenu();

            String food;

            while (true) {

                System.out.print("\nEnter Food Name: ");
                food = sc.nextLine();

                if (food.equalsIgnoreCase("Pizza")
                        || food.equalsIgnoreCase("Burger")
                        || food.equalsIgnoreCase("Shawarma")) {
                    break;
                }

                System.out.println("Invalid Food! Please enter again.");
            }

            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();
            sc.nextLine();

            r.addOrder(food, quantity);

            System.out.print("Do you want to order another item? (yes/no): ");
            choice = sc.nextLine();

        } while (choice.equalsIgnoreCase("yes"));

        r.getBill();

        sc.close();
    }
}