/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class ExceptionHandling
{
	public static void main(String[] args) {
		try {
			int n=10,m=0;

			int c=n/m;
			System.out.println(c);
			
		}
		catch(ArithmeticException e) {
			System.out.println("cannot divided by Zero");

		}finally {
			System.out.println("Program end");
		}
	}
}

