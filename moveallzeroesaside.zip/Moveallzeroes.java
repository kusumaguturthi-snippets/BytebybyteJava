/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Moveallzeroes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] array = new int[5];

        System.out.println("Enter 5 numbers:");

        for (int i = 0; i < array.length; i++) {
            array[i] = sc.nextInt();
        }

        int[] temp = new int[array.length];
        int index = 0;

        // Copy non-zero elements
        for (int i = 0; i < array.length; i++) {
            if (array[i] != 0) {
                temp[index++] = array[i];
            }
        }

        // Print result
        System.out.println("After moving zeros to the end:");
        for (int i = 0; i < temp.length; i++) {
            System.out.print(temp[i]+" ");
        }

        sc.close();
    }
}
