/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import  java.util.Scanner;
public  class   ATMPin {
	public  static  void  main  (String[]  args)  {
		Scanner  sc  =  new  Scanner(System.in)  ;
		System.out.print("Enter  Password :");
		int correctPin = 6334;
		System.out.println("Enter ATM PIN:");
		int  pin = sc.nextInt();
		if  ( pin == correctPin  )  {
			System.out.println("Access Granted" )  ;
		}  else  {
			System.out.println("Invalid PIN" );

		}
	}
}