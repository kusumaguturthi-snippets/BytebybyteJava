/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

abstract class ATM {

    abstract void deposit(double amount);

    abstract void withdraw(double amount);

    abstract void checkBalance();
}

class BankAccount extends ATM {

    // Encapsulation
    private int pin = 5380;
    private double balance = 10000;

    public boolean verifyPin(int enteredPin) {
        return pin == enteredPin;
    }

    @Override
    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit Successful");
        System.out.println("Updated Balance: " + balance);
    }

    @Override
    void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdraw Successfully");
            System.out.println("Remaining Balance: " + balance);
        } else {
            System.out.println("Insufficient Balance");
        }
    }

    @Override
    void checkBalance() {
        System.out.println("Current Balance: " + balance);
    }
}

public class ATMBanking {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        BankAccount acc = new BankAccount();

        System.out.print("Enter PIN: ");
        int enteredPin = sc.nextInt();

        if (acc.verifyPin(enteredPin)) {

            acc.checkBalance();

            acc.deposit(5000);

            acc.withdraw(3000);

            acc.checkBalance();

        } else {
            System.out.println("Invalid PIN");
        }

        sc.close();
    }
}