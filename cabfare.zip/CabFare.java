/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class CabFare
{
   
	public static void main(String[] args) {
	     Scanner sc =new Scanner(System.in);
    
		System.out.println("Enter distance in KM:");
		int attendance = sc.nextInt();
		double km= sc.nextDouble();
		double fare = 50 +(km*12);
		
		    System.out.println("Total Fare:"+fare);
		}
	}

