/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class pattern1
{
	public static void main(String[] args) {
int num = 0;		
for(int i=1; i<=5; i++){  
for(int j=1; j<=i; j++){ 
    num++;
System.out.print(num); 
}
System.out.println();
}
	}
}
