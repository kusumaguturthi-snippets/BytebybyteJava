/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
    public class Main{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int n , sum=0;
	    System.out.print("Enter number of elements:");
	    n = sc.nextInt();
	    int arr[] = new int[n];
		System.out.println("Enter elemnts:");
		for ( int i = 0; i<arr.length; i++){
		    arr[i] =sc.nextInt();
		    sum = sum+arr[i];
		}
		System.out.println("Sum of elements =" +sum);
	}
}

