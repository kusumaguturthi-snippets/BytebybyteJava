/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class SelectionSort
{
	public static void main(String[] args) {
	   
        int a[] = {4, 2, 5, 2, 7};

        for (int i = 0; i < a.length; i++) {

            for (int j = i + 1; j < a.length; j++) {

                if (a[i] > a[j]) {

                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }

        // sorted array print
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }
}