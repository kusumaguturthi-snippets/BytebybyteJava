/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Cookie1
{
	void Oreo() {

		System.out.println("This is not fortified snack");
	}
	public static void main(String[] args) {
		Cookie1 OreoCookie = new Cookie1();
		OreoCookie.Oreo();
	}
}
