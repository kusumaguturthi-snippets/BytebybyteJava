/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import  java.util.Scanner;
public  class  PasswordChecker  {
	public  static  void  main  (  String[]  args  )  {
		Scanner  sc  =  new  Scanner(System.in)  ;
		System.out.print("Enter  Password :")  ;
		String  password  =  sc.nextLine();
		if  (  password.length()>=8  )  {
			System.out.println("Strong  Password" )  ;
		}  else  {
			System.out.println("Weak  Password" );

		}
	}
}