import java.util.Scanner;

public class FoodOrdering {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int choice, quantity;
        int price = 0;
        int totalBill = 0;
        String another = "yes";

        do {
            System.out.println("\n----- MENU -----");
            System.out.println("1. Pizza    - ₹100");
            System.out.println("2. Burger   - ₹80");
            System.out.println("3. Shawarma - ₹120");

            System.out.print("Enter Choice (1-3): ");
            choice = sc.nextInt();

            System.out.print("Enter Quantity: ");
            quantity = sc.nextInt();

            switch (choice) {
                case 1:
                    price = 100;
                    System.out.println("Ordered: Pizza");
                    break;

                case 2:
                    price = 80;
                    System.out.println("Ordered: Burger");
                    break;

                case 3:
                    price = 120;
                    System.out.println("Ordered: Shawarma");
                    break;

                default:
                    System.out.println("Invalid Choice!");
                    continue;
            }

            int amount = price * quantity;
            totalBill += amount;

            System.out.println("Amount = ₹" + amount);

            System.out.print("Do you want another order? (yes/no): ");
            another = sc.nextLine();

        } while (another == "yes" || another == "YES");
         another = sc.nextLine();

        System.out.println("\nTotal Bill = ₹" + totalBill);

        sc.close();
    }
}