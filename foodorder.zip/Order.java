/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
class Order
{
   void pizza()
   {
       System.out.println("Pizza  Ordered✅");
   }
   void burger()
   {
       System.out.println("Burger  Ordered ✅");
       
   }
   
   void bill()
   {
       System.out.println("Total bill is 350$");
   }
   
	public static void main(String[] args) {
	  
	  Order customer = new Order();
	   customer.pizza();
	   customer.burger();
	   customer.bill();
	  }
}
