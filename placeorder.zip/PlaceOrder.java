

import java.util.Scanner;

abstract class Order{
	
	abstract void showMenu();
	abstract void add(int quqntity);
	abstract void getBill();
}
class Restaurant extends Order{
	//encapsulation
	private String foodName = "Shawarma";
	private int quantity;
	private double price = 130;
	private double totalBill;
	//@Override
	void showMenu() {
		System.out.println("Food item:"+foodName);
		System.out.println("Price    :"+price);
	}
	void add(int quantity) {
		this.quantity = quantity;
		totalBill = price * quantity;
		System.out.println("Order Placed Successfully!");
	}
	void getBill() {
		System.out.println("\n----- BILL -----");
		System.out.println("Food Item : "+ foodName);
		System.out.println("Quantity  : "+ quantity);
		System.out.println("Total Bill:"+ totalBill);
	}
		
	}
 public class PlaceOrder{
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 Restaurant customer = new  Restaurant();
		 customer.showMenu();
		 System.out.println("Enter Quantity:");
		 int qty = sc.nextInt();
		 customer.add(qty);
		 customer.getBill();
		 sc.close();
		 
	 }
}

