/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
  class Employee{
      void work(){
      System.out.println("Employee is working.");
  }
  }
  class Developer extends Employee{
      void code(){
          System.out.println("Developer writes code.");

      }
  }
   public class Main{
       public static void main(String[] args){
           Developer d = new Developer();
           d.work();
           d.code();
           
       }
   }