/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class EmployeeBonus
{
	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);

		System.out.println("Enter salary:");
		double salary = sc.nextDouble();
		double bonus;
		if (salary < 30000) {
			bonus = salary * 0.15;
		}
		else {
			bonus =salary * 0.05;
		}
		System.out.println("Final Salary:" +(salary+bonus));

	}
}
