import java.util.*;
class BankAccount {
    private double balance;
    public void deposit(double amount)
    {
        balance += amount;
    }
    public void withdraw(double amount){
        if (amount <= balance){
            balance -= amount;
        }
    }
    public double getBalance(){
        return balance;
    }
}
 public class Main{
     public static void main(String[] args){
         BankAccount acc=new BankAccount();
         acc.deposit(5000);
         acc.withdraw(1000);
         System.out.println("Balance:" + acc.getBalance());
     }
 }