/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
		System.out.println("Enter size of array:");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter array elements:");
		for( int i=0;i<arr.length;i++){
		    arr[i] = sc.nextInt();
	}
	int greatest =arr[0];
	int smallest =arr[0];
	for(int i = 0; i < arr.length;i++){
	    if(arr[i]>greatest){
	        greatest = arr[i];
	    }
	    if(arr[i]<smallest){
	        smallest = arr[i];
	    }
	}
	System.out.println("Greatest number:"+ greatest);
	System.out.println("Smallest number:" + smallest);
	}
	
}