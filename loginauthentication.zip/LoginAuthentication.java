/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class LoginAuthentication
{
	public static void main(String[] args) {
	   Scanner sc = new Scanner(System.in);
	       
	       String password = "Suma5390";
	   try{
	       System.out.println("Enter the Student Name:");
	       String name = sc.nextLine();
	       
	       System.out.println("Enter the Id: ");
	       int id = sc.nextInt();
	       sc.nextLine();
	       // consume leftover newline
	       
	      
	       
	       
	       if(!password.equals("Suma5390")){
	           throw new Exception("Invalid Password");
	       }
	       System.out.println("Login Successfully");
	       System.out.println("Welcome " + name + " (ID: " + id + ")");
	   }
	   catch(Exception e){
	       System.out.println(e.getMessage());
	   }
	   finally{
	       System.out.println("Successful!");
	       sc.close();
	   }
	}
}
